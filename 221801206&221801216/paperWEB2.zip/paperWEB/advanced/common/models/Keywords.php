<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "keywords".
 *
 * @property integer $keywordid
 * @property string $keywordname
 * @property integer $keyWordCount
 */
class Keywords extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'keywords';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['keywordid', 'keywordname', 'keyWordCount'], 'required'],
            [['keywordid', 'keyWordCount'], 'integer'],
            [['keywordname'], 'string'],
            [['keywordid'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'keywordid' => 'Keywordid',
            'keywordname' => 'Keywordname',
            'keyWordCount' => 'Key Word Count',
        ];
    }

    public static function string2array($keyword){
        return preg_split('/\s*,\s*/',trim($keyword),-1,PREG_SPLIT_NO_EMPTY);
    }

    public static function array2string($keyword){
        return implode(', ',$keyword);
    }

    public static function addKeys($keyword){
        if(empty($keyword)) return ;

        foreach($keyword as $name){
            $akey = Keywords::find()->where(['keywordname'=>$name])->one();
            $akeyCount = Keywords::find()->where(['keywordname'=>$name])->count();
            
            if(!$akeyCount){
                $keyword = new Keywords;
                $keyword->keywordname = $name;
                $keyword->keyWordCount = 1;
                $keyword->save();
            }
            else{
                $akey->keyWordCount += 1;
                $akey->save();
            }
        }
    }

    public static function removeKeys($keywords){
        if(empty($keywords)) return ;

        foreach($keywords as $name){

            $akey = Keywords::find()->where(['keywordname'=>$name])->one();
            $akeyCount = Keywords::find()->where(['keywordname'=>$name])->count();
            
            if($akeyCount){
                if($akey->keyWordCount <= 1){
                    $akey->delete();
                }
                else{
                    $akey->keyWordCount -= 1;
                    $akey->save();
                }
            }
        }
    }

    public static function updateFrequency($oldkeys, $newkeys){
        if(!empty($oldkeys) || !empty($newkeys)){
            $oldkeysArray = self::string2array($oldkeys);
            $newkeysArray = self::string2array($newkeys);

            self::addKeys(array_values(array_diff($newkeysArray,$oldkeysArray)));
            self::removeKeys(array_values(array_diff($oldkeysArray,$newkeysArray)));
        }
    }

    public static function findKeyWeights($limit=20)
    {
    	$key_size_level = 5;
    	 
    	$models=Keywords::find()->orderBy('keyWordCount desc')->limit($limit)->all();
    	$total=Keywords::find()->limit($limit)->count();
    	 
    	$stepper=ceil($total/$key_size_level);
    	 
    	$keys=array();
    	$counter=1;
    	 
    	if($total>0)
    	{
    		foreach ($models as $model)
    		{
    			$weight=ceil($counter/$stepper)+1;
    			$tags[$model->name]=$weight;
    			$counter++;
    		}
    		ksort($keys);
    	}
    	return $keys;
    }
}
