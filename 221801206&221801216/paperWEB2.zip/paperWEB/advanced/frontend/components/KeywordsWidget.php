<?php
namespace frontend\components;

use yii\base\Widget;
use yii\helpers\Html;
use common\models\Keywords;
use Yii;
use commmon\models\Paperstore;

class KeywordsWidget extends Widget
{
	public $keywords;
	
	public function init()
	{
		parent::init();
	}
	
	public function run()
	{
		$keyString='';
		$fontStyle=array("6"=>"danger",
				"5"=>"info",
				"4"=>"warning",
				"3"=>"primary",
				"2"=>"success",
		);
		
		foreach ($this->keywords as $keywords=>$weight)
		{
			$keyString.='<a href="'.\Yii::$app->homeUrl.'?r=keywords/index&PaperstoreSearch[keyword]='
					.$keywords.'">'.
					' <h'.$weight.' style="display:inline-block;"><span class="label label-'
					.$fontStyle[$weight].'">'.$keywords.'</span></h'.$weight.'></a>';
		}
		return $keyString;
		
	}	
}