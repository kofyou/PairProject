<?php

/* @var $this yii\web\View */

$this->title = 'Paper Garden';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Welcome to PaperWEB</h1>

 
        

    </div>
</div>
