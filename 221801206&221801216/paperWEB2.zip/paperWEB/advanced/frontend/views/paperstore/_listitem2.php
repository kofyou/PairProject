<?php
use yii\helpers\Html;
use common\models\Paperstore;

?>

<div class="paper">
	<div class="test">
        <div class="title" >
        <br>
        <span  style="font-weight:bold" aria-hidden="true"></span>
        <em>
        <?= Html::encode($model->displayTitle);?>
        </em>	
		<hr>
        </div>
	</div>
	
</div>