<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ListView;
use yii\caching\DbDependency;
use frontend\components\KeywordsWidget;
use common\models\Keywords;
use common\models\Paperstore;
use common\models\PaperstoreSearch;
use frontend\controllers\PaperstoreController;

/* @var $this yii\web\View */
/* @var $searchModel common\models\PostSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

?>
<div class="paperstore-keyindex">
<div class="container">

	<div class="row">
	
		<div class="col-md-9">
		
		<ol class="breadcrumb">
		<li><a href="<?= Yii::$app->homeUrl;?>">首页</a></li>
		<li>关键词谱</li>
		
		</ol>
        <?php 
        $searchModel = new PaperstoreSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        ?>
		<?= ListView::widget([
				'id'=>'paperstore',
				'dataProvider'=>$dataProvider,
				'itemView'=>'_listitem2',//子视图,显示一篇文章的标题等内容.
				'layout'=>'{items} {pager}',
				'pager'=>[
						'maxButtonCount'=>10,
						'nextPageLabel'=>Yii::t('app','下一页'),
						'prevPageLabel'=>Yii::t('app','上一页'),
		],
		])?>
		
		</div>

		<div class="keycloudbox">
				<ul class="list-group">
				  <li class="list-group-item">
				  <span class="glyphicon glyphicon-tags" aria-hidden="true"></span> 关键词谱
				  </li>
				  <li class="list-group-item">
					<?= KeywordsWidget::widget(['keywords'=>$keywords]);?>
				  </li>
				</ul>			
		</div>		
		</div>
		
		
	</div>

</div>
</div>