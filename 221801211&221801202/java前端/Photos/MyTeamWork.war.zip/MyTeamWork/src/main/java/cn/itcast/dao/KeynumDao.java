package cn.itcast.dao;

import cn.itcast.domain.PaperInfo;

import java.util.List;
import java.util.Map;

public interface KeynumDao {
    Map<String,Integer> add();
}
